
package giuaky22;

public interface IThanhToan {
	double tinhTien();
}
