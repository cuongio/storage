package thanhtoan.exe;

//import java.io.BufferedReader;
//import java.io.BufferedWriter;
//import java.io.FileReader;
//import java.io.FileWriter;
//import java.io.IOException;
//import java.util.ArrayList;
//import java.util.Collections;
//import java.util.Comparator;
//import java.util.List;

import java.io.*;
import java.util.*;

class QLDSKH {
    private List<TienDien> dskh;

    public QLDSKH() {
        dskh = new ArrayList<>();
    }

    // Đọc file input
    public void docFile(String tenFile) throws IOException {
        BufferedReader br = new BufferedReader(new FileReader(tenFile));
        String line;
        while ((line = br.readLine()) != null) {
            String[] parts = line.split(", ");
            String loai = parts[0];
            String tenKH = parts[1];
            int soLuong = Integer.parseInt(parts[2]);

            if (loai.equals("CN")) {
                dskh.add(new TDHoCaNhan(tenKH, soLuong));
            } else if (loai.equals("TC")) {
                int mucDo = Integer.parseInt(parts[3]);
                dskh.add(new TDToChuc(tenKH, soLuong, mucDo));
            }
        }
        br.close();
    }

    // Tìm kiếm khách hàng có tiền điện cao nhất
    public void timKiemMax() {
        TienDien maxKH = Collections.max(dskh, Comparator.comparingDouble(TienDien::tinhTien));
        System.out.println("Khách hàng có tiền điện cao nhất: " + maxKH);
    }

    // Lưu thông tin hộ cá nhân vào file
    public void ghiFile(String tenFile) throws IOException {
        BufferedWriter bw = new BufferedWriter(new FileWriter(tenFile));
        for (TienDien kh : dskh) {
            if (kh instanceof TDHoCaNhan) {
                bw.write(kh.toString());
                bw.newLine();
            }
        }
        bw.close();
    }

    // Thêm đối tượng HoSanXuat
    public void themHoSanXuat(String tenKH, int soLuong) {
        dskh.add(new HoSanXuat(tenKH, soLuong));
    }
}