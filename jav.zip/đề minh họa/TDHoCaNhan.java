package thanhtoan.exe;

class TDHoCaNhan extends TienDien {
    public TDHoCaNhan(String tenKH, int soLuong) {
        super(tenKH, soLuong);
    }

    @Override
    public String loaiTD() {
        return "CN";
    }

    @Override
    public double tinhTien() {
        int dinhMuc = 100;
        if (soLuong <= dinhMuc) {
            return soLuong * 500;
        } else {
            return dinhMuc * 500 + (soLuong - dinhMuc) * 800;
        }
    }
}

