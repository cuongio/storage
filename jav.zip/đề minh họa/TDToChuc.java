package thanhtoan.exe;

class TDToChuc extends TienDien {
    private int mucDo;

    public TDToChuc(String tenKH, int soLuong, int mucDo) {
        super(tenKH, soLuong);
        this.mucDo = mucDo;
    }

    @Override
    public String loaiTD() {
        return "TC";
    }

    @Override
    public double tinhTien() {
        int dinhMuc;
        switch (mucDo) {
            case 1:
                dinhMuc = 1000;
                break;
            case 2:
                dinhMuc = 2000;
                break;
            case 3:
                dinhMuc = 5000;
                break;
            default:
                dinhMuc = 0;
        }

        if (soLuong <= dinhMuc) {
            return soLuong * 400;
        } else {
            return dinhMuc * 400 + (soLuong - dinhMuc) * 1000;
        }
    }
}
