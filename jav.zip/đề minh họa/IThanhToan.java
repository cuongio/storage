package thanhtoan.exe;

interface IThanhToan {
   double tinhTien();
}




