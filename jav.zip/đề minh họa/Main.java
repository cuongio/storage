package thanhtoan.exe;

import java.io.IOException;
import thanhtoan.exe.TDHoCaNhan;

public class Main {
	public static void main(String[] args) { 
        QLDSKH ql = new QLDSKH();

        // Đọc file input
        try {
			ql.docFile("src/input.txt");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

        // Tìm kiếm khách hàng có tiền điện cao nhất
        ql.timKiemMax();

        // Lưu thông tin hộ cá nhân vào file
        try {
			ql.ghiFile("src/HoCaNhan.dat");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

        // Thêm hộ sản xuất mới
        ql.themHoSanXuat("Nguyen Van D", 250);

        System.out.println("Danh sách sau khi thêm HoSanXuat: ");
        ql.timKiemMax();
	}

}
