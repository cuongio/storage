package thanhtoan.exe;

abstract class TienDien implements IThanhToan{
  protected String tenKH;
  protected int soLuong;
  
  public TienDien(String tenKH, int soLuong) {
	  this.tenKH = tenKH;
	  this.soLuong = soLuong;
  }
  public abstract String loaiTD();
  
  @Override
  public String toString() {
	  return "Tên Khách Hàng: " + tenKH + ", Số Lượng: " + soLuong + ", Loại: " + loaiTD() +", Tiền điện:" + tinhTien();  
  }
}

