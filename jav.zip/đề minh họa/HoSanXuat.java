package thanhtoan.exe;

class HoSanXuat extends TienDien {
    public HoSanXuat(String tenKH, int soLuong) {
        super(tenKH, soLuong);
    }

    @Override
    public String loaiTD() {
        return "SX";
    }

    @Override
    public double tinhTien() {
        int dinhMuc = 200;
        if (soLuong <= dinhMuc) {
            return soLuong * 1000;
        } else {
            return dinhMuc * 1000 + (soLuong - dinhMuc) * 1500;
        }
    }
}