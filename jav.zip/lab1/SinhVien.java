package lab1;
import java.util.ArrayList;
import java.util.List;
class SinhVien {
    private String hoTen;
    private List<Diem> danhSachDiem;

    public SinhVien(String hoTen) {
        this.hoTen = hoTen;
        this.danhSachDiem = new ArrayList<>();
    }

    public void themHocPhan(Diem diem) {
        danhSachDiem.add(diem);
    }

    public double tinhDTB() {
        double tongDiem = 0;
        int tongTinChi = 0;

        for (Diem diem : danhSachDiem) {
            tongDiem += diem.tinhDiem() * diem.getSoTinChi();
            tongTinChi += diem.getSoTinChi();
        }

        return danhSachDiem.isEmpty() ? 0 : tongDiem / tongTinChi;
    }

    public void hienThiThongTin() {
        System.out.println("Họ tên: " + hoTen);
        for (Diem diem : danhSachDiem) {
            System.out.println("  " + diem.hienThiThongTin());
        }
        System.out.println("Điểm trung bình: " + String.format("%.2f", tinhDTB()));
    }
}