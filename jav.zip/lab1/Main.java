package lab1;

public class Main {
    public static void main(String[] args) {
        // Tạo các học phần
        Diem diem1 = new Diem("Toán", 3, 8, 7, 9);
        Diem diem2 = new Diem("Lý", 2, 7, 6, 8);
        Diem diem3 = new Diem("Hóa", 3, 9, 8, 10);
        Diem diem4 = new Diem("Sinh học", 2, 6, 7, 8);
        Diem diem5 = new Diem("Tin học", 4, 10, 9, 9);

        // Tạo danh sách sinh viên
        SinhVien sv1 = new SinhVien("Nguyễn Văn A");
        sv1.themHocPhan(diem1);
        sv1.themHocPhan(diem2);

        SinhVien sv2 = new SinhVien("Trần Thị B");
        sv2.themHocPhan(diem3);
        sv2.themHocPhan(diem4);

        SinhVien sv3 = new SinhVien("Lê Văn C");
        sv3.themHocPhan(diem1);
        sv3.themHocPhan(diem5);

        // Tạo mảng chứa sinh viên
        SinhVien[] danhSachSinhVien = {sv1, sv2, sv3};

        // Hiển thị thông tin sinh viên và điểm trung bình
        for (SinhVien sv : danhSachSinhVien) {
            sv.hienThiThongTin();
            System.out.println(); // Dòng trống giữa các sinh viên
        }
    }
}