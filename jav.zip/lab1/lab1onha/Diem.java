package lab1onha;
import java.util.Arrays;

//Lớp Diem
class Diem {
 private double x, y;

 // Constructor
 public Diem(double x, double y) {
     this.x = x;
     this.y = y;
 }

 // Phương thức tính khoảng cách tới điểm khác
 public double khoangCach(Diem p) {
     return Math.sqrt(Math.pow(this.x - p.x, 2) + Math.pow(this.y - p.y, 2));
 }

 // Phương thức chuyển thành chuỗi
 @Override
 public String toString() {
     return String.format("(%.2f, %.2f)", x, y);
 }

 // Getter
 public double getX() {
     return x;
 }

 public double getY() {
     return y;
 }
}
