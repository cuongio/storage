package lab1onha;


import java.util.Arrays;

class HCN {
    private Diem d1, d2;

    // Constructor
    public HCN(Diem d1, Diem d2) {
        this.d1 = d1;
        this.d2 = d2;
    }

    // Tính chu vi
    public double chuVi() {
        double width = Math.abs(d2.getX() - d1.getX());
        double height = Math.abs(d2.getY() - d1.getY());
        return 2 * (width + height);
    }

    // Tính diện tích
    public double dienTich() {
        double width = Math.abs(d2.getX() - d1.getX());
        double height = Math.abs(d2.getY() - d1.getY());
        return width * height;
    }

    // Phương thức chuyển thành chuỗi
    @Override
    public String toString() {
        return String.format("[%s, %s]", d1.toString(), d2.toString());
    }
}