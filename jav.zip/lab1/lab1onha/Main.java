package lab1onha;
import java.util.Arrays;

public class Main {
    public static void main(String[] args) {
        // Tạo mảng 5 hình chữ nhật
        HCN[] rectangles = new HCN[5];
        rectangles[0] = new HCN(new Diem(0, 4), new Diem(3, 0));
        rectangles[1] = new HCN(new Diem(1, 5), new Diem(4, 1));
        rectangles[2] = new HCN(new Diem(2, 6), new Diem(5, 2));
        rectangles[3] = new HCN(new Diem(0, 3), new Diem(2, 0));
        rectangles[4] = new HCN(new Diem(1, 4), new Diem(3, 1));

        // Hiển thị thông tin ban đầu
        System.out.println("Danh sách các hình chữ nhật:");
        for (HCN rectangle : rectangles) {
            System.out.printf("%s - Chu vi: %.2f, Diện tích: %.2f\n",
                    rectangle.toString(), rectangle.chuVi(), rectangle.dienTich());
        }

        // Sắp xếp theo diện tích tăng dần
        Arrays.sort(rectangles, (r1, r2) -> Double.compare(r1.dienTich(), r2.dienTich()));

        // Hiển thị thông tin sau khi sắp xếp
        System.out.println("\nDanh sách các hình chữ nhật sau khi sắp xếp theo diện tích tăng dần:");
        for (HCN rectangle : rectangles) {
            System.out.printf("%s - Chu vi: %.2f, Diện tích: %.2f\n",
                    rectangle.toString(), rectangle.chuVi(), rectangle.dienTich());
        }
    }
}
