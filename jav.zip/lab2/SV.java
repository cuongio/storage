package lab2;

import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class SV {
    private String hoTen;
    private Date ngaySinh;
    private double dtb;

    public SV(String hoTen, Date ngaySinh, double dtb) {
        this.hoTen = hoTen.trim();
        this.ngaySinh = ngaySinh;
        this.dtb = dtb;
    }

    public String layHoTen() {
        return hoTen;
    }

    public void ganHoTen(String hoTen) {
        this.hoTen = hoTen.trim();
    }

    public Date layNgaySinh() {
        return ngaySinh;
    }

    public void ganNgaySinh(Date ngaySinh) {
        this.ngaySinh = ngaySinh;
    }

    public double layDTB() {
        return dtb;
    }

    public void ganDTB(double dtb) {
        this.dtb = dtb;
    }

    public void hienThi() {
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        System.out.printf("Họ tên: %s, Ngày sinh: %s, Điểm trung bình: %.2f, Xếp loại: %s%n",
                hoTen, sdf.format(ngaySinh), dtb, layXepLoai());
    }

    public String layHo() {
        return hoTen.split(" ")[0];
    }

    public String layTen() {
        String[] parts = hoTen.split(" ");
        return parts[parts.length - 1];
    }

    public String layDem() {
        String[] parts = hoTen.split(" ");
        if (parts.length <= 2) return "";
        StringBuilder dem = new StringBuilder();
        for (int i = 1; i < parts.length - 1; i++) {
            dem.append(parts[i]).append(" ");
        }
        return dem.toString().trim();
    }

    public int layTuoi() {
        Calendar current = Calendar.getInstance();
        Calendar birth = Calendar.getInstance();
        birth.setTime(ngaySinh);
        return current.get(Calendar.YEAR) - birth.get(Calendar.YEAR);
    }

    public String layXepLoai() {
        if (dtb >= 8) return "Giỏi";
        if (dtb >= 7) return "Khá";
        if (dtb >= 5) return "Trung bình";
        return "Yếu";
    }

    public boolean lonHon(SV other) {
        return this.layTuoi() > other.layTuoi();
    }

    public boolean gioiHon(SV other) {
        return this.dtb > other.dtb;
    }

    public boolean giongNhau(SV other) {
        return this.hoTen.equalsIgnoreCase(other.hoTen)
                && this.ngaySinh.equals(other.ngaySinh)
                && this.dtb == other.dtb;
    }

    public void chuanHoTen() {
        this.hoTen = this.hoTen.trim().replaceAll("\\s+", " ");
    }
}
