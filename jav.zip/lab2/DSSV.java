package lab2;

import java.util.Arrays;
import java.util.Calendar;
import java.util.Comparator;

import java.util.*;

public class DSSV {
    private List<SV> danhSach;

    public DSSV(int soLuong) {
        danhSach = new ArrayList<>(soLuong);
    }

    public void them(SV sv) {
        danhSach.add(sv);
    }

    public SV laySV(int index) {
        return danhSach.get(index);
    }

    public void hienThi() {
        for (SV sv : danhSach) {
            sv.hienThi();
        }
    }

    public void sapHoten() {
        danhSach.sort((sv1, sv2) -> {
            String s1 = sv1.layTen() + " " + sv1.layHo() + " " + sv1.layDem();
            String s2 = sv2.layTen() + " " + sv2.layHo() + " " + sv2.layDem();
            return s1.compareToIgnoreCase(s2);
        });
    }

    public void sapTuoi() {
        danhSach.sort(Comparator.comparingInt(SV::layTuoi));
    }

    public void sapDTB() {
        danhSach.sort((sv1, sv2) -> Double.compare(sv2.layDTB(), sv1.layDTB()));
    }

    public void timTen(String ten) {
        for (SV sv : danhSach) {
            if (sv.layTen().equalsIgnoreCase(ten)) {
                sv.hienThi();
            }
        }
    }

    public void lietKeXepLoai(String xepLoai) {
        for (SV sv : danhSach) {
            if (sv.layXepLoai().equalsIgnoreCase(xepLoai)) {
                sv.hienThi();
            }
        }
    }

    public void xoa(String ten) {
        danhSach.removeIf(sv -> sv.layTen().equalsIgnoreCase(ten));
    }

    public double tinhTuoiTrungBinh() {
        return danhSach.stream().mapToInt(SV::layTuoi).average().orElse(0);
    }

    public void tangDTB() {
        for (SV sv : danhSach) {
            if (sv.layTuoi() > 2023 - 1980) {  // Lấy năm hiện hành
                sv.ganDTB(sv.layDTB() + 0.5);
            }
        }
    }

    public void chuanHoTen() {
        for (SV sv : danhSach) {
            sv.chuanHoTen();
        }
    }

    public void trungSV() {
        for (int i = 0; i < danhSach.size(); i++) {
            for (int j = i + 1; j < danhSach.size(); j++) {
                if (danhSach.get(i).giongNhau(danhSach.get(j))) {
                    danhSach.get(i).hienThi();
                }
            }
        }
    }
}

