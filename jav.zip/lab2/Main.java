package lab2;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;



import java.text.ParseException;
import java.text.SimpleDateFormat;

public class Main {
    public static void main(String[] args) throws ParseException {
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        DSSV ds = new DSSV(5);

        ds.them(new SV("Nguyễn Văn An", sdf.parse("01/01/1985"), 7.5));
        ds.them(new SV("Trần Văn Hòa", sdf.parse("02/02/1990"), 8.5));
        ds.them(new SV("Lê Thị Lan", sdf.parse("15/05/1980"), 6.5));
        ds.them(new SV("Phạm Minh Nam", sdf.parse("10/10/2000"), 9.0));
        ds.them(new SV("Đỗ Ngọc Hòa", sdf.parse("20/11/1982"), 5.5));

        System.out.println("Danh sách ban đầu:");
        ds.hienThi();

        System.out.println("\nSắp xếp theo họ tên:");
        ds.sapHoten();
        ds.hienThi();

        System.out.println("\nSinh viên giỏi:");
        ds.lietKeXepLoai("Giỏi");

        System.out.println("\nTìm sinh viên tên Nam:");
        ds.timTen("Nam");

        System.out.println("\nXóa sinh viên đầu tiên tên Hòa:");
        ds.xoa("Hòa");
        ds.hienThi();

        System.out.println("\nTuổi trung bình:");
        System.out.printf("%.2f%n", ds.tinhTuoiTrungBinh());

        System.out.println("\nTăng điểm trung bình cho sinh viên sinh trước năm 1980:");
        ds.tangDTB();
        ds.hienThi();

        System.out.println("\nChuẩn hóa họ tên:");
        ds.chuanHoTen();
        ds.hienThi();

        System.out.println("\nSinh viên trùng nhau:");
        ds.trungSV();
    }
}
