package jav;

//Abstract class NhanVien
import java.util.*;

abstract class NhanVien implements ILuong {
protected String maNV;
protected String hoTen;
protected Date ngaySinh;

public NhanVien(String maNV, String hoTen, Date ngaySinh) {
   this.maNV = maNV;
   this.hoTen = hoTen;
   this.ngaySinh = ngaySinh;
}

public abstract String loaiNV();

@Override
public String toString() {
   return "Ma NV: " + maNV + ", Ho Ten: " + hoTen + ", Ngay Sinh: " + ngaySinh;
}
}