package jav;

import java.io.Serializable;
import java.util.Date;

class NhanVienHDG extends NhanVien  implements Serializable {
    private double luongGio;
    private int soGio;
    public NhanVienHDG(String maNV, String hoTen, Date ngaySinh, double luongGio, int soGio) {
        super(maNV, hoTen, ngaySinh);
        this.luongGio = luongGio;
        this.soGio = soGio;
    }
    @Override
    public double tinhLuong() {
        if (soGio > 160) {
            return (160 * luongGio) + ((soGio - 160) * 1.5 * luongGio);
        } else {
            return soGio * luongGio;
        }
    }
    @Override
    public String loaiNV() {
        return "TG";
    }
    @Override
    public String toString() {
        return super.toString() + ", Loai NV: " + loaiNV() + ", Luong: " + tinhLuong();
    }
}
