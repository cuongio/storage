package jav;

import java.text.SimpleDateFormat;

public class Main {
    public static void main(String[] args) {
        try {
            QLNhanVien qlnv = new QLNhanVien();

            // Doc file input.txt
            qlnv.docFile("src/input.txt");

            // Hien thi danh sach nhan vien
            System.out.println("Danh sach nhan vien:");
            qlnv.hienThi();

            // Sap xep va hien thi
            qlnv.sapXep();
            System.out.println("\nDanh sach nhan vien sau khi sap xep theo luong:");
            qlnv.hienThi();

            // Ghi file NhanVienHDG.dat
            qlnv.ghiFile("src/NhanVienHDG.dat");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
