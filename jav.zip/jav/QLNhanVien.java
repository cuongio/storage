package jav;

import java.text.SimpleDateFormat;
/*import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Scanner;*/
import java.io.*;
import java.util.*;

//QLNhanVien class
class QLNhanVien {
private List<NhanVien> dsnv;

public QLNhanVien() {
   dsnv = new ArrayList<>();
}

public void docFile(String tenFile) throws Exception {
   Scanner scanner = new Scanner(new File(tenFile));
   while (scanner.hasNextLine()) {
       String line = scanner.nextLine();
       String[] parts = line.split(", ");
       String loai = parts[0];
       String maNV = parts[1];
       String hoTen = parts[2];
       Date ngaySinh = new SimpleDateFormat("MM/dd/yyyy").parse(parts[3]);

       if (loai.equals("DH")) {
           double luongThang = Double.parseDouble(parts[4]);
           dsnv.add(new NhanVienHDDH(maNV, hoTen, ngaySinh, luongThang));
       } else if (loai.equals("TG")) {
           double luongGio = Double.parseDouble(parts[4]);
           int soGio = Integer.parseInt(parts[5]);
           dsnv.add(new NhanVienHDG(maNV, hoTen, ngaySinh, luongGio, soGio));
       }
   }
   scanner.close();
}

public void sapXep() {
   dsnv.sort(Comparator.comparingDouble(NhanVien::tinhLuong));
}

public void ghiFile(String tenFile) throws Exception {
   try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(tenFile))) {
       for (NhanVien nv : dsnv) {
           if (nv instanceof NhanVienHDG) {
               oos.writeObject(nv);
           }
       }
   }
}

public void hienThi() {
   for (NhanVien nv : dsnv) {
       System.out.println(nv);
   }
}
}
