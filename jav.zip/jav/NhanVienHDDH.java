package jav;

import java.util.Date;

//NhanVienHDDH class
class NhanVienHDDH extends NhanVien {
private double luongThang;

public NhanVienHDDH(String maNV, String hoTen, Date ngaySinh, double luongThang) {
   super(maNV, hoTen, ngaySinh);
   this.luongThang = luongThang;
}

@Override
public double tinhLuong() {
   return luongThang;
}

@Override
public String loaiNV() {
   return "DH";
}

@Override
public String toString() {
   return super.toString() + ", Loai NV: " + loaiNV() + ", Luong: " + tinhLuong();
}
}
