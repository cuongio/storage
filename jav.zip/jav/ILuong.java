package jav;

interface ILuong {
   double tinhLuong();
}

