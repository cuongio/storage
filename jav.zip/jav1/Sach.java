package jav1;

//Lớp trừu tượng Sach
abstract class Sach {
 // Thuộc tính mã sách
 protected String maSach;
 // Thuộc tính nhà xuất bản
 protected String nhaXuatBan;
 // Thuộc tính số lượng sách
 protected int soLuong;
 // Thuộc tính đơn giá của sách
 protected double donGia;

 // Constructor để khởi tạo các thuộc tính
 public Sach(String maSach, String nhaXuatBan, int soLuong, double donGia) {
     this.maSach = maSach;
     this.nhaXuatBan = nhaXuatBan;
     this.soLuong = soLuong;
     this.donGia = donGia;
 }

 // Phương thức trừu tượng để tính thành tiền, được lớp con triển khai
 public abstract double thanhTien();

 // Phương thức liệt kê thông tin sách
 public void lietKe() {
     System.out.println("Mã sách: " + maSach + ", Nhà xuất bản: " + nhaXuatBan + ", Số lượng: " + soLuong + ", Đơn giá: " + donGia);
 }
}
