package jav1;
//Chương trình chính
public class Main {
 public static void main(String[] args) {
     // Tạo đối tượng quản lý sách
     QuanLySach qls = new QuanLySach();

     // Nhập 5 loại sách (2 sách giáo khoa, 2 sách tham khảo)
     qls.them(new SachGiaoKhoa("SGK1", "NXB1", 10, 15000, 1)); // Sách giáo khoa mới
     qls.them(new SachGiaoKhoa("SGK2", "NXB2", 5, 12000, 2)); // Sách giáo khoa cũ
     qls.them(new SachThamKhao("STK1", "NXB3", 7, 20000, 5000)); // Sách tham khảo 1
     qls.them(new SachThamKhao("STK2", "NXB4", 3, 25000, 3000)); // Sách tham khảo 2

     // Liệt kê thông tin tất cả các loại sách
     System.out.println("Danh sách các loại sách:");
     qls.lietKe();

     // Ghi thông tin vào tệp QuanLySach.dat
     qls.ghiTep("QuanLySach.dat");

     // Đọc thông tin từ tệp và in ra màn hình
     System.out.println("\nNội dung từ tệp QuanLySach.dat:");
     qls.docTep("QuanLySach.dat");

     // Tính và in tổng tiền của tất cả các loại sách
     System.out.println("\nTổng tiền của tất cả các loại sách: " + qls.tongTien());
 }
}
