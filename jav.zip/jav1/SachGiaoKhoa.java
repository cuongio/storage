package jav1;

//Lớp SachGiaoKhoa kế thừa từ lớp Sach
class SachGiaoKhoa extends Sach {
 // Thuộc tính tình trạng sách (1: mới, 2: cũ)
 private int tinhTrang;

 // Constructor để khởi tạo các thuộc tính
 public SachGiaoKhoa(String maSach, String nhaXuatBan, int soLuong, double donGia, int tinhTrang) {
     super(maSach, nhaXuatBan, soLuong, donGia); // Gọi constructor của lớp cha
     this.tinhTrang = tinhTrang;
 }

 // Triển khai phương thức tính thành tiền
 @Override
 public double thanhTien() {
     // Nếu tình trạng sách là mới, thành tiền = số lượng * đơn giá
     // Nếu tình trạng sách là cũ, thành tiền = số lượng * đơn giá * 50%
     return tinhTrang == 1 ? soLuong * donGia : soLuong * donGia * 0.5;
 }

 // Ghi đè phương thức liệt kê để hiển thị thêm tình trạng và thành tiền
 @Override
 public void lietKe() {
     super.lietKe(); // Gọi phương thức liệt kê của lớp cha
     System.out.println(", Tình trạng: " + (tinhTrang == 1 ? "Mới" : "Cũ") + ", Thành tiền: " + thanhTien());
 }
}