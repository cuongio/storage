package jav1;

//Giao diện QuanLyTep
interface QuanLyTep {
 // Phương thức đọc tệp, nhận vào tên tệp
 void docTep(String tenTep);
 // Phương thức ghi tệp, nhận vào tên tệp
 void ghiTep(String tenTep);
}
