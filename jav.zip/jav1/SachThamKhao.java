package jav1;

//Lớp SachThamKhao kế thừa từ lớp Sach
class SachThamKhao extends Sach {
 // Thuộc tính thuế của sách tham khảo
 private double thue;

 // Constructor để khởi tạo các thuộc tính
 public SachThamKhao(String maSach, String nhaXuatBan, int soLuong, double donGia, double thue) {
     super(maSach, nhaXuatBan, soLuong, donGia); // Gọi constructor của lớp cha
     this.thue = thue;
 }

 // Triển khai phương thức tính thành tiền
 @Override
 public double thanhTien() {
     // Thành tiền = số lượng * đơn giá + thuế
     return soLuong * donGia + thue;
 }

 // Ghi đè phương thức liệt kê để hiển thị thêm thuế và thành tiền
 @Override
 public void lietKe() {
     super.lietKe(); // Gọi phương thức liệt kê của lớp cha
     System.out.println(", Thuế: " + thue + ", Thành tiền: " + thanhTien());
 }
}