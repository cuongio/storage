package jav1;

//Lớp QuanLySach quản lý danh sách các loại sách
import java.io.*;
import java.util.*;

class QuanLySach implements QuanLyTep {
 // Danh sách các sách được quản lý
 private List<Sach> ds;

 // Constructor để khởi tạo danh sách
 public QuanLySach() {
     ds = new ArrayList<>();
 }

 // Phương thức thêm một sách vào danh sách
 public void them(Sach s) {
     ds.add(s);
 }

 // Phương thức liệt kê toàn bộ sách trong danh sách
 public void lietKe() {
     for (Sach s : ds) {
         s.lietKe();
     }
 }

 // Phương thức ghi thông tin các loại sách vào tệp
 @Override
 public void ghiTep(String tenTep) {
     try (BufferedWriter writer = new BufferedWriter(new FileWriter(tenTep))) {
         for (Sach s : ds) {
             // Ghi thông tin sách giáo khoa mới và sách tham khảo
             if (s instanceof SachGiaoKhoa && ((SachGiaoKhoa) s).thanhTien() > 0) {
                 writer.write(s.maSach + " - " + s.nhaXuatBan + " - " + s.thanhTien());
                 writer.newLine();
             } else if (s instanceof SachThamKhao) {
                 writer.write(s.maSach + " - " + s.nhaXuatBan + " - " + s.thanhTien());
                 writer.newLine();
             }
         }
     } catch (IOException e) {
         System.out.println("Lỗi ghi tệp: " + e.getMessage());
     }
 }

 // Phương thức đọc thông tin sách từ tệp
 @Override
 public void docTep(String tenTep) {
     try (BufferedReader reader = new BufferedReader(new FileReader(tenTep))) {
         String line;
         // Đọc từng dòng và in ra màn hình
         while ((line = reader.readLine()) != null) {
             System.out.println(line);
         }
     } catch (IOException e) {
         System.out.println("Lỗi đọc tệp: " + e.getMessage());
     }
 }

 // Phương thức tính tổng tiền của tất cả các loại sách trong danh sách
 public double tongTien() {
     double tong = 0;
     for (Sach s : ds) {
         tong += s.thanhTien();
     }
     return tong;
 }
}